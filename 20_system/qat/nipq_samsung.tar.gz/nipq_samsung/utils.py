import torch
from collections import deque
from models.quantizer import Quantizer
from models.mobilenetv2 import MobileNetV2
from models.resnext import CifarResNeXt
from models.resnet import ResNet
import math
import numpy as np
from models.quantizer import get_metric, get_data


def cosine_with_warmup(
    total_epochs: int,
    warmup_epochs: int = 0,
    low: float = 0.0,
    high: float = 1.0,
):
    assert total_epochs > warmup_epochs

    def _cosine_with_warmup(epoch: int) -> float:
        if epoch < warmup_epochs:
            return (epoch + 1) / warmup_epochs * high
        else:
            return (
                1
                + math.cos(
                    math.pi
                    * (epoch + 1 - warmup_epochs)
                    / (total_epochs - warmup_epochs)
                )
            ) * 0.5 * (high - low) + low

    return _cosine_with_warmup


def eval_custom(
    model, dataloader, accuracy_accum, loss_accum=None, loss_fn=None
):
    accuracy_accum.reset()
    if loss_accum is not None:
        loss_accum.zero_()

    use_ste = deque()
    for m in model.modules():
        if isinstance(m, Quantizer):
            use_ste.append(m.use_ste)
            m.use_ste = True
    with torch.no_grad():
        for X, Y in dataloader:
            prediction = model(X)
            if loss_fn is not None:
                loss_accum.add_(loss_fn(prediction, Y))
            accuracy_accum(prediction, Y)

    for m in model.modules():
        if isinstance(m, Quantizer):
            m.use_ste = use_ste.popleft()

    return accuracy_accum.compute(), loss_accum / len(dataloader)


def get_model(name, *args, **kwargs):
    if name == "mobilenetv2":
        model = MobileNetV2(*args, **kwargs)
    elif name == "resnet32":
        model = ResNet(depth=32, block_name="BasicBlock", *args, **kwargs)
    elif name == "resnext_8x64d":
        model = CifarResNeXt(
            cardinality=8, widen_factor=4, depth=29, *args, **kwargs
        )
    elif name == "resnext_16x64d":
        model = CifarResNeXt(
            cardinality=16, widen_factor=4, depth=29, *args, **kwargs
        )
    elif name == "resnet164":
        model = ResNet(depth=164, block_name="Bottleneck", *args, **kwargs)
    else:
        raise NotImplementedError(name)
    return model


def get_log_dict(
    fabric,
    model,
    optimizer,
    epoch,
    time_epoch_start,
    time_epoch_end,
    total_epochs,
    train_acc,
    test_acc,
    train_loss,
    test_loss,
    is_saved,
    target_type=None,
    quant=False,
    test_q_acc=None,
    test_q_loss=None,
    quant_w=False,
    quant_a=False,
):
    epoch_log = {
        "epoch": epoch + 1,
        "tot": total_epochs,
        "acc": test_acc.item(),
        "train_acc": train_acc.item(),
        "loss": train_loss.item(),
        "test_loss": test_loss.item(),
        "mem_reserved": torch.cuda.max_memory_reserved(device=fabric.device)
        * 2**-30,
        "mem_allocated": torch.cuda.max_memory_allocated(device=fabric.device)
        * 2**-30,
    }
    for gi, group in enumerate(optimizer.param_groups):
        epoch_log.update({f"lr_{gi}": group["lr"]})
    if is_saved:
        epoch_log.update({"saved": True})

    for gi, group in enumerate(optimizer.param_groups):
        if gi == 1:
            # skip Hessian for parameters without momentum (BN bias, ...)
            break
        for pi, p in enumerate(group["params"]):
            state = optimizer.state[p]
            if "hessian" in state:
                epoch_log.update(
                    {f"H_{gi}_{pi}_mean": state["hessian"].mean().item()}
                )
                epoch_log.update(
                    {
                        f"H_{gi}_{pi}_std": state["hessian"]
                        .std(correction=0)
                        .item()
                    }
                )

    duration = time_epoch_end - time_epoch_start
    epoch_log.update({"time": duration})

    if quant:
        metric = get_metric(model, metric=target_type, q_w=quant_w, q_a=quant_a)
        baseline = get_metric(model, metric=target_type, baseline=True)
        ratio = baseline / metric
        epoch_log.update({f"test_q_acc": test_q_acc.item()})
        epoch_log.update({f"test_q_loss": test_q_loss.item()})
        epoch_log.update({f"{target_type}": metric.item()})
        epoch_log.update({f"{target_type}_baseline": baseline})
        epoch_log.update({f"{target_type}_ratio": ratio.item()})

        alpha = np.array(
            get_data(model, "alpha", get_w=quant_w, get_a=quant_a)
        ).T
        bitwidth = np.array(
            get_data(model, "bit", get_w=quant_w, get_a=quant_a)
        ).T
        print(f"a: {alpha}")
        print(f"b: {bitwidth}")

        legend = ["w", "x"]
        for aii, ai in enumerate(alpha):
            for aij, a in enumerate(ai):
                epoch_log.update({f"a_{legend[aii]}_{aij}": a})
        for bii, bi in enumerate(bitwidth):
            for bij, b in enumerate(bi):
                epoch_log.update({f"b_{legend[bii]}_{bij}": b})
                a = alpha[bii][bij]
                epoch_log.update(
                    {f"step_{legend[bii]}_{bij}": a / (2 ** (b - 1) - 1)}
                )

    return epoch_log


def log_str(dict):
    def _log_str(kv):
        k, v = kv

        if k.startswith("a_") or k.startswith("b_") or k.startswith("step_"):
            return ""
        elif k.startswith("H_"):  # skip printing Hessian log
            return ""
        elif isinstance(v, float):
            return f"{k}: {v:.5f}"
        elif isinstance(v, int):
            return f"{k}: {v:d}"
        else:
            raise ValueError(f"Unknown key-value pair {k}, {v}")

    l = dict.items()
    return "\t".join(filter(None, map(_log_str, l)))


def get_param_dict(model):
    params = []
    no_decay_params = []
    for name, param in model.named_parameters():
        name_arr = name.split(".")
        if name_arr[-1] in [
            "bias",
            "alpha_baseline",
            "alpha_delta",
            "_bit_options",
            "bit_logit",
        ]:
            no_decay_params.append(param)
        else:
            params.append(param)

    param_dict = [
        {"params": params},
        {"params": no_decay_params, "weight_decay": 0.0},
    ]

    return param_dict


def get_teacher(teacher, dir, dataset, num_classes):
    import os

    model = None
    if teacher is not None:
        teacher_dir = os.path.join(*[dir, teacher, dataset, "best.pth.tar"])
        assert os.path.isfile(
            teacher_dir
        ), "Error: no checkpoint directory for teacher found!"
        checkpoint = torch.load(teacher_dir)

        state_dict = checkpoint["state_dict"]
        from collections import OrderedDict

        new_state_dict = OrderedDict()

        for k, v in state_dict.items():
            if "module" in k:
                k = k[7:]
            new_state_dict[k] = v

        model = get_model(teacher, num_classes=num_classes)
        model.load_state_dict(new_state_dict)

    return model
