#!/bin/bash
tag=$(date '+%Y%m%d')

CUDA_VISIBLE_DEVICES=0 python3 ../train.py\
  --optimizer sgd --lambda_t 0.002\
  --quant_w --target 8.0 --pretrain_epochs 0 --nipq_epochs 30 --lr 2.4\
  --mask_frac 0.1 --tag "${tag}" &
wait
echo "done!"
