import torch
import torchvision.datasets as dsets
import torchvision.transforms as transforms


def get_dataset(dataset, batch_size, dir):
    if dataset not in ["mnist", "cifar10", "cifar100"]:
        raise NotImplementedError(f"{dataset}")
    num_classes = -1

    if dataset == "mnist":
        transform = transforms.Compose(
            [transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))]
        )
        train_dset = dsets.MNIST(
            root=dir,
            train=True,
            transform=transform,
            download=True,
        )

        test_dset = dsets.MNIST(
            root=dir,
            train=False,
            transform=transform,
            download=True,
        )
        num_classes = 10
    elif dataset == "cifar10":
        transform_train = transforms.Compose(
            [
                transforms.RandomCrop(32, padding=4),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize(
                    (0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)
                ),
            ]
        )

        transform_test = transforms.Compose(
            [
                transforms.ToTensor(),
                transforms.Normalize(
                    (0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)
                ),
            ]
        )
        train_dset = dsets.CIFAR10(
            root=dir,
            train=True,
            download=True,
            transform=transform_train,
        )
        test_dset = dsets.CIFAR10(
            root=dir,
            train=False,
            download=True,
            transform=transform_test,
        )
        num_classes = 10
    elif dataset == "cifar100":
        transform_train = transforms.Compose(
            [
                transforms.RandomCrop(32, padding=4),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize(
                    (0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)
                ),
            ]
        )
        transform_test = transforms.Compose(
            [
                transforms.ToTensor(),
                transforms.Normalize(
                    (0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)
                ),
            ]
        )
        train_dset = dsets.CIFAR100(
            root=dir, train=True, download=True, transform=transform_train
        )
        test_dset = dsets.CIFAR100(
            root=dir, train=False, download=True, transform=transform_test
        )
        num_classes = 100
    else:
        raise ValueError(dataset)

    data_loader_train = torch.utils.data.DataLoader(
        dataset=train_dset, batch_size=batch_size, shuffle=True, drop_last=False
    )
    data_loader_test = torch.utils.data.DataLoader(
        dataset=test_dset, batch_size=batch_size, shuffle=False, drop_last=False
    )

    return data_loader_train, data_loader_test, num_classes
