import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


# Quantization modules
class roundpass(torch.autograd.Function):
    @staticmethod
    def forward(ctx, input):
        return torch.round(input)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output


roundpass = roundpass.apply


def get_noise(x, noise_type=3, seed=None):
    noise = None

    if seed is not None:
        torch.manual_seed(seed)

    if noise_type == 1:
        # option 1. uniform (var=1/12)
        noise = torch.zeros_like(x).uniform_(-0.5, 0.5)
    elif noise_type == 2:
        # option 2. rounded normal (var=1/12)
        noise = torch.zeros_like(x).normal_().mul_(0.5).round_().mul_(0.5)
    elif noise_type == 3:
        # option 3. rounded uniform (var=1/4)
        noise = (
            torch.zeros_like(x)
            .uniform_(-0.5, 0.5)
            .mul_(1.5)
            .round_()
            .mul_(0.866)
        )
    elif noise_type == 4:
        # option 4. rounded normal for higher Hessian diagonal SNR (var=1/4)
        noise = torch.zeros_like(x).normal_().mul_(0.433).round_()
    else:
        raise ValueError(f"Unknown noise type {noise_type}")

    return noise


class noisyQ(torch.autograd.Function):
    # TODO activation -> ignore batch dim
    @staticmethod
    def forward(ctx, input, stepsize, seed):
        noise = get_noise(input, seed=seed.item())
        ctx.save_for_backward(seed)

        # return input + noise * stepsize
        return noise.mul_(stepsize).add_(input)

    @staticmethod
    def backward(ctx, grad_output):
        seed = ctx.saved_tensors[0]

        noise = get_noise(grad_output, seed=seed.item())

        return grad_output, torch.sum(grad_output * noise), None


noisyQ = noisyQ.apply


class Quantizer(nn.Module):
    # global hyperparameters
    tau_init = 1.0
    alpha_init = "stddev"
    assert alpha_init in ["stddev", "minmax"]
    bit_options = [2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0]
    # bit_options = [2.0, 4.0, 4.0, 8.0, 8.0, 8.0, 8.0]
    bit_init = 8.0
    assert bit_init in bit_options
    bit_init_idx = bit_options.index(bit_init)

    def __init__(self, is_weight: bool):
        super(Quantizer, self).__init__()

        # bitwidth logit
        self._bit_options = nn.Parameter(
            torch.tensor(Quantizer.bit_options), requires_grad=False
        )
        bit_logit = torch.zeros_like(self._bit_options)
        bit_logit[Quantizer.bit_init_idx] = 2.0
        self.bit_logit = nn.Parameter(bit_logit, requires_grad=True)

        # temperature for Gumbel-Softmax
        self.gumbel_tau = Quantizer.tau_init

        # input distribution parameters
        self.is_weight = is_weight
        # will be updated at `update_dist_params`
        self.tracker = None if self.is_weight else DistTracker()
        self.asym_min = None
        self.is_sym = True

        self.alpha_baseline = nn.Parameter(
            torch.tensor(0.0), requires_grad=False
        )  # will be initialized at `_init_with_x`
        self.alpha_delta = nn.Parameter(torch.tensor(0.0), requires_grad=True)

        # flags, initialization
        self.use_ste = False
        self.is_on = False
        self.is_initialized = False
        self.input_dim = [1, 1, 1, 1]
        self.input_size = 1

        # seed for PRNG
        self.prng_seed = None

    def update_dist_params(self, x):
        if self.is_weight:
            return

        is_updated = self.tracker.update(x)
        if is_updated:
            asym_min = self.tracker.get_lb()
            self.asym_min = asym_min
            self.is_sym = True if asym_min is None else False

    def _init_with_x(self, x):
        if self.is_initialized:
            return

        # quantization range alpha
        def reverse_softplus(x):
            return np.log(np.exp(x) - 1.0)

        if Quantizer.alpha_init == "stddev":
            self.alpha_baseline += reverse_softplus(3 * x.std().item())
        elif Quantizer.alpha_init == "minmax":
            self.alpha_baseline += reverse_softplus(
                (x.max().item() - x.min().item()) * 0.5
            )

        # input dimension
        if self.is_weight:
            self.input_dim = x.shape
            self.input_size = x.view([-1]).shape[0]
        else:
            self.input_dim = x.shape[1:]  # ignore batch dim
            self.input_size = x.view([x.shape[0], -1]).shape[1]
        self.is_initialized = True

    def use_fixed(self):
        return self.use_ste or not self.training or not self.is_on

    def get_bitwidth(self):
        # gumbel softmax scheme
        sample_logit = None
        if self.use_fixed():
            sample_logit = F.one_hot(
                torch.argmax(self.bit_logit),
                num_classes=self.bit_logit.shape[0],
            )
        else:
            sample_logit = F.gumbel_softmax(
                self.bit_logit, tau=self.gumbel_tau, hard=self.use_ste
            )
        bitwidth = torch.sum(sample_logit * self._bit_options)

        return bitwidth

    def get_alpha(self):
        return F.softplus(self.alpha_baseline + self.alpha_delta)

    def quantize(self, x):
        if not self.is_initialized:
            self._init_with_x(x)
        self.update_dist_params(x)

        # symmetric quantization
        # num_steps = 2 ** self.get_bitwidth() - 2
        num_steps_half = 2 ** (self.get_bitwidth() - 1) - 1
        alpha = self.get_alpha()

        # 2 * alpha / num_steps
        rev_num_steps_half = torch.reciprocal(num_steps_half)
        stepsize = alpha * rev_num_steps_half

        off = 0
        if not self.is_sym:
            off = alpha + self.asym_min

        if self.use_fixed():
            # bugfix: divide by stepsize yields 0 gradient
            # scaled = (x - off) / stepsize
            scaled = (x - off) * (num_steps_half / alpha)

            rounded = roundpass(scaled)

            # bugfix: multiply by stepsize yields NaN
            # q_x = (
            #     torch.clamp(rounded, -num_steps_half, num_steps_half)
            #     * (alpha / num_steps_half)
            #     + off
            # )
            q_x = F.hardtanh(rounded / num_steps_half) * alpha + off
        else:
            q_x = (
                torch.clamp(
                    noisyQ(x - off, stepsize, self.prng_seed), -alpha, alpha
                )
                + off
            )

        return q_x

    def forward(self, x):
        if self.is_on:
            x = self.quantize(x)
        return x


"""### Quantization aware modules"""


class QConv2d(nn.Conv2d):
    def __init__(self, *args, **kwargs):
        super(QConv2d, self).__init__(*args, **kwargs)
        self.q_w = Quantizer(is_weight=True)
        self.q_a = Quantizer(is_weight=False)

        self.q_w.input_dim = self.weight.shape
        self.q_w.input_size = self.weight.view([-1]).shape[0]

    def forward(self, x):
        q_w = self.q_w(self.weight)
        q_x = self.q_a(x)
        return F.conv2d(
            q_x,
            q_w,
            bias=self.bias,
            stride=self.stride,
            padding=self.padding,
            dilation=self.dilation,
            groups=self.groups,
        )


class QLinear(nn.Linear):
    def __init__(self, *args, **kwargs):
        super(QLinear, self).__init__(*args, **kwargs)
        self.q_w = Quantizer(is_weight=True)
        self.q_a = Quantizer(is_weight=False)

        self.q_w.input_dim = self.weight.shape
        self.q_w.input_size = self.weight.view([-1]).shape[0]

    def forward(self, x):
        q_w = self.q_w(self.weight)
        q_x = self.q_a(x)

        return F.linear(q_x, q_w, bias=self.bias)


class QuantOps(object):
    Conv2d = QConv2d
    Linear = QLinear


# helper functions


class DistTracker:
    def __init__(self, update_period=100):
        self.idx = 0

        self.name = [
            "ReLU",
            "Hardswish",
            "SiLU",
            "Mish",
            "GELU",
            "GELU_tanh",
        ]
        self.lb = np.array(
            [0, -0.375, -0.27846, -0.30884, -0.169971, -0.17004075]
        )
        self.update_period = update_period
        self.update_step = -1

    # input
    #   new minimum to update
    # return
    #   updated index
    def min_to_act(self, new_min: float):
        if new_min < min(self.lb):
            # input is added with residual --> handle as symmetric
            return None

        # minimum should only decrease
        current_lb = self.lb[self.idx]
        diff_L1 = abs(self.lb - new_min)
        diff_min_idx = np.argmin(diff_L1)

        # update only if new minimum is effectively smaller than current minimum
        if current_lb - new_min > 1e-4:
            return diff_min_idx
        else:
            return self.idx

    def get_lb(self):
        if self.idx is None:
            return None
        return self.lb[self.idx]

    # input
    #   activation tensor
    # return
    #   is_updated: bool
    def update(self, x):
        # symmetric --> early return
        if self.idx is None:
            return False

        # update with period
        self.update_step = (self.update_step + 1) % self.update_period
        if self.update_step != 0:
            return False

        new_min = min(self.get_lb(), x.min().item())
        new_idx = self.min_to_act(new_min)

        prev_idx = self.idx
        self.idx = new_idx

        return prev_idx == new_idx


# callback
class QuantizerCallback:
    def set_q(self, model, q_w=True, q_a=True):
        for m in model.modules():
            if isinstance(m, QConv2d) or isinstance(m, QLinear):
                m.q_w.is_on = q_w
                m.q_w.bit_logit.requires_grad = q_w
                m.q_a.is_on = q_a
                m.q_a.bit_logit.requires_grad = q_a

    def set_ste(self, model, ste=True):
        for m in model.modules():
            if isinstance(m, QConv2d) or isinstance(m, QLinear):
                m.q_w.use_ste = ste
                m.q_w.bit_logit.requires_grad = not ste
                m.q_a.use_ste = ste
                m.q_a.bit_logit.requires_grad = not ste

    def update_gumbel_tau_exp(self, model, decay):
        # from 1812.03443
        # init=5.0, decay=exp(-0.045)=~0.956 per epoch
        assert 0.0 < decay and decay < 1.0
        for m in model.modules():
            if isinstance(m, Quantizer):
                m.gumbel_tau *= decay

    def update_model_qmask(self, model, mask, q_w=True, q_a=True):
        idx = 0
        prev_v = False
        for m in model.modules():
            curr_v = False
            if q_w and hasattr(m, "q_w"):
                v = idx in mask
                curr_v |= v
                m.q_w.is_on = v
                m.q_w.bit_logit.requires_grad = v  # for regularizer
            if hasattr(m, "q_a"):
                v = (idx in mask) and (q_a or not m.q_a.is_initialized)
                curr_v |= v
                m.q_a.is_on = v
                m.q_a.bit_logit.requires_grad = v  # for regularizer
            if hasattr(m, "q_w") or hasattr(m, "q_a"):
                idx += 1

            # freeze BN right after conv / linear layer
            # if isinstance(m, nn.BatchNorm2d):
            #     if prev_v:
            #         m.bias.requires_grad = False
            #         prev_v = False
            #     else:
            #         m.bias.requires_grad = True
            #         prev_v = curr_v
            # else:
            #     prev_v = curr_v

    def update_seed(self, model):
        for m in model.modules():
            if isinstance(m, QConv2d) or isinstance(m, QLinear):
                if hasattr(m, "q_w"):
                    m.q_w.prng_seed = torch.randint(
                        low=0, high=2**32, size=[1]
                    )
                if hasattr(m, "q_a"):
                    m.q_a.prng_seed = torch.randint(
                        low=0, high=2**32, size=[1]
                    )


# get statistics
def get_data(model, t: str = "bit", get_w: bool = True, get_a: bool = True):
    assert t in ["bit", "alpha"]
    assert get_w or get_a

    data = []
    for m in model.modules():
        local_data = []
        if hasattr(m, "q_w") and get_w:
            if t == "bit":
                local_data.append(m.q_w.get_bitwidth().item())
            elif t == "alpha":
                local_data.append(m.q_w.get_alpha().item())
        if hasattr(m, "q_a") and get_a:
            if t == "bit":
                local_data.append(m.q_a.get_bitwidth().item())
            elif t == "alpha":
                local_data.append(m.q_a.get_alpha().item())
        if len(local_data) > 0:
            data.append(local_data)
    return data


def get_metric(
    model,
    metric: str = "bitops",
    baseline: bool = False,
    q_w: bool = False,
    q_a: bool = False,
):
    assert metric in ["bitops", "bit_w", "bit_a", "bit_both"]

    scale_lambda = 2.0**-10

    def conv_out_hw(in_hw, kernel_size, padding, stride, dilation):
        return (
            in_hw + 2 * padding - dilation * (kernel_size - 1) - 1
        ) / stride + 1

    def bitops(
        k, in_c, out_h, out_w, out_c, bit_w, bit_a, scale_lambda=2.0**-10
    ):
        out_elem = (out_h * out_w * out_c) * scale_lambda
        compute_per_elem = (k[0] * k[1] * in_c) * scale_lambda
        return compute_per_elem * out_elem * bit_w * bit_a

    metric_accum = 0
    for m in model.modules():
        a_size = None
        a_bit = None
        w_size = None
        w_bit = None

        valid_a = False
        valid_w = False

        if hasattr(m, "q_w"):
            w_size = m.q_w.input_size * scale_lambda
            if baseline or not q_w:
                w_bit = 32.0
            else:
                w_bit = m.q_w.get_bitwidth()
            valid_w = True
        if hasattr(m, "q_a"):
            a_size = m.q_a.input_size * scale_lambda
            if baseline or not q_a:
                a_bit = 32.0
            else:
                a_bit = m.q_a.get_bitwidth()
            valid_a = True

        metric_val = None
        if metric == "bitops" and valid_a and valid_w:
            # calculate bitops
            kernel_size = None
            out_h = None
            out_w = None
            if isinstance(m, nn.Conv2d):
                kernel_size = m.kernel_size
                out_h = round(
                    conv_out_hw(
                        m.q_a.input_dim[1],  # (B, C, H, W) --> (C, H, W)
                        kernel_size[0],
                        m.padding[0],
                        m.stride[0],
                        m.dilation[0],
                    )
                )
                out_w = round(
                    conv_out_hw(
                        m.q_a.input_dim[2],
                        kernel_size[1],
                        m.padding[1],
                        m.stride[1],
                        m.dilation[1],
                    )
                )
            elif isinstance(m, nn.Linear):
                kernel_size = (1, 1)
                out_h = 1
                out_w = 1
            else:
                raise NotImplementedError(m)
            metric_val = bitops(
                kernel_size,
                m.weight.shape[1],
                out_h,
                out_w,
                m.weight.shape[0],
                w_bit,
                a_bit,
                scale_lambda,
            )
        elif metric == "bit_w" and valid_w:
            metric_val = w_size * w_bit
        elif metric == "bit_a" and valid_a:
            metric_val = a_size * a_bit
        elif metric == "bit_both" and valid_a and valid_w:
            metric_val = a_size * a_bit + w_size * w_bit

        if metric_val is not None:
            # GiBOPs or MiB
            metric_accum += metric_val * scale_lambda

    return metric_accum


def get_input_dist(model):
    arr = []
    for m in model.modules():
        if isinstance(m, Quantizer):
            if m.is_weight:
                continue
            if m.tracker.idx is None:
                arr.append(None)
            else:
                arr.append(m.tracker.lb[m.tracker.idx])
    return arr


def get_num_qlayers(model):
    cnt = 0
    for m in model.modules():
        if hasattr(m, "q_w") or hasattr(m, "q_a"):
            cnt += 1
    return cnt
